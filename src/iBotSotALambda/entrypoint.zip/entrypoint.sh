#!/bin/bash
#/usr/bin/xray-daemon -f /var/log/xray-daemon.log &
dotnet iBotSotALambda.dll
